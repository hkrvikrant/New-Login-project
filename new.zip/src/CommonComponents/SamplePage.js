import React from 'react'

export default function SamplePage() {
    return (
        <div style={{display:'flex',height:'100vh',justifyContent:'center',flexDirection:'column'}}>
                <h1 style={{textAlign:'center', color:'blue'}} >Coming Soon!!</h1>
        </div>
    )
}
